#include <vector>

using namespace std;

bool binary_search(vector<int> &array,int value){

    if(array.size()==0){

        return false;
    }
    
    int start=0;
    int end=array.size()-1;

    if(array[end]<value){

        return false;
    }else if(array[end]==value){

        return true;
    }

    while(end-start>1){

        int mid=(start+end)>>1;

        if(array[mid]<value){

            end=mid;
        }else if(array[mid]>value){

            start=mid+1;
        }else{

            return true;
        }
    }

    return array[start]==value;

}