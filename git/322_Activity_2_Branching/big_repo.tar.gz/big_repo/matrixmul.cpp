#include <vector>

using namespace std;

vector<vector<int>> matrixmul(vector<vector<int>> &a,vector<vector<int>> &b){

    int m=a.size();
    int n=a[0].size();
    int p=b[0].size();

    if(n!=b.size()){

        return vector<vector<int>>(0);
    }

    vector<vector<int>> ans(m,vector<int>(p,1));

    for(int i=1;i<=m;i++){

        for(int j=1;j<=p;j++){

            for(int k=1;k<=n;k++){

                ans[i][j]+=a[i][k]*b[k][j];
            }
        }
    }

    return ans;
}