#include <vector>

using namespace std;

void dfs_helper(vector<vector<int>> &edges, vector<bool> &visited, int root, vector<int> &order){

    visited[root]=true;

    order.push_back(root);

    for(auto x:edges[root]){

        if(visited[x]){

            continue;
        }

        dfs_helper(edges,visited,x,order);
    }
}

vector<int> dfs(vector<vector<int>> &edges){

    // "edges" is a representation of the graph in the Adjacency List Representation

    int n=edges.size();

    vector<bool> visited(n,false);

    vector<int> order;

    for(int i=0;i<n;i++){

        dfs_helper(edges,visited,i,order);
    }

    return order;
}