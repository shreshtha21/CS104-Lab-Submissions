#include <vector>

using namespace std;

vector<int> sieve(int n){

    vector<int> primes;

    vector<int> sieve_erts(n+1,0);

    for(int i=2;i<=n;i++){

        if(sieve_erts[i]){

            continue;
        }

        primes.push_back(i);
        sieve_erts[i]=i;
        int j=2*i;

        while(j<=n){
            
            sieve_erts[j]=i;
            j+=i;
        }
    }

    return primes;
}