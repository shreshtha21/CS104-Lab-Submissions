This is a sample repository to get familiar with the features of GIT.

Here, we try to build a simple program to add 2 numbers.